
import React, { useState } from 'react';
import { Plus, Sparkles } from 'lucide-react';
import TaskList from '../components/TaskList';
import TaskForm from '../components/TaskForm';
import { Task } from '../types/Task';

const Index = () => {
  const [tasks, setTasks] = useState<Task[]>([
    {
      id: '1',
      title: 'Welcome to Your Creative Space',
      description: 'Start your productivity journey with this beautifully designed task manager!',
      dueDate: new Date().toISOString().split('T')[0],
      status: 'pending',
      priority: 'medium',
      createdAt: new Date().toISOString()
    }
  ]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  const addTask = (taskData: Omit<Task, 'id' | 'createdAt'>) => {
    const newTask: Task = {
      ...taskData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    };
    setTasks([newTask, ...tasks]);
    setIsFormOpen(false);
  };

  const updateTask = (id: string, taskData: Omit<Task, 'id' | 'createdAt'>) => {
    setTasks(tasks.map(task => 
      task.id === id 
        ? { ...task, ...taskData }
        : task
    ));
    setEditingTask(null);
    setIsFormOpen(false);
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setEditingTask(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-ocean-50 via-lavender-50 to-forest-50 font-sans">
      {/* Header with updated design */}
      <div className="bg-gradient-to-r from-ocean-600 via-lavender-600 to-forest-600 shadow-2xl border-b border-white/10 sticky top-0 z-40 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-white/15 rounded-2xl backdrop-blur-lg border border-white/20">
                <Sparkles className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-display font-bold text-white drop-shadow-lg tracking-tight">
                  NexusTask
                </h1>
                <p className="text-white/80 mt-1 font-medium text-lg">
                  {tasks.length} {tasks.length === 1 ? 'task' : 'tasks'} in your workspace
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsFormOpen(true)}
              className="bg-gradient-to-r from-sunset-500 to-sunset-600 text-white px-8 py-4 rounded-2xl flex items-center gap-3 hover:from-sunset-600 hover:to-sunset-700 transition-all duration-300 transform hover:scale-105 shadow-2xl hover:shadow-sunset-500/30 font-semibold text-lg border border-white/20"
            >
              <Plus size={24} strokeWidth={2.5} />
              New Task
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-8 py-10">
        <TaskList 
          tasks={tasks} 
          onEditTask={handleEditTask}
          onDeleteTask={deleteTask}
          onUpdateTask={updateTask}
        />
      </div>

      {/* Task Form Modal */}
      {isFormOpen && (
        <TaskForm
          task={editingTask}
          onSubmit={editingTask ? 
            (taskData) => updateTask(editingTask.id, taskData) : 
            addTask
          }
          onClose={handleCloseForm}
        />
      )}
    </div>
  );
};

export default Index;
