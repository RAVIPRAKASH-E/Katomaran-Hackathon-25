
import React from 'react';
import { Calendar, Edit3, Trash2, AlertTriangle, Flag, Star } from 'lucide-react';
import { Task } from '../types/Task';

interface TaskCardProps {
  task: Task;
  onEdit: (task: Task) => void;
  onDelete: (id: string) => void;
  onUpdateStatus: (status: Task['status']) => void;
}

const TaskCard: React.FC<TaskCardProps> = ({ task, onEdit, onDelete, onUpdateStatus }) => {
  const getPriorityStyles = (priority: string) => {
    switch (priority) {
      case 'high': 
        return {
          badge: 'text-red-800 bg-gradient-to-r from-red-100 to-red-200 border-red-300 shadow-red-200/60',
          card: 'border-l-red-500 shadow-red-100/40'
        };
      case 'medium': 
        return {
          badge: 'text-sunset-800 bg-gradient-to-r from-sunset-100 to-sunset-200 border-sunset-300 shadow-sunset-200/60',
          card: 'border-l-sunset-500 shadow-sunset-100/40'
        };
      case 'low': 
        return {
          badge: 'text-forest-800 bg-gradient-to-r from-forest-100 to-forest-200 border-forest-300 shadow-forest-200/60',
          card: 'border-l-forest-500 shadow-forest-100/40'
        };
      default: 
        return {
          badge: 'text-gray-800 bg-gradient-to-r from-gray-100 to-gray-200 border-gray-300 shadow-gray-200/60',
          card: 'border-l-gray-500 shadow-gray-100/40'
        };
    }
  };

  const getStatusStyles = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-gradient-to-r from-forest-500 to-forest-600';
      case 'in-progress': return 'bg-gradient-to-r from-ocean-500 to-ocean-600';
      case 'pending': return 'bg-gradient-to-r from-sunset-500 to-sunset-600';
      default: return 'bg-gradient-to-r from-gray-400 to-gray-500';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  const isOverdue = new Date(task.dueDate) < new Date() && task.status !== 'completed';
  const styles = getPriorityStyles(task.priority);

  return (
    <div className={`bg-white/95 backdrop-blur-lg rounded-3xl p-7 shadow-2xl hover:shadow-3xl transition-all duration-500 transform hover:-translate-y-3 border-l-4 ${styles.card} hover:bg-white border border-white/30`}>
      <div className="flex items-start justify-between mb-6">
        <div className="flex-1">
          <h3 className="font-display font-bold text-gray-900 mb-4 text-xl line-clamp-2 leading-tight">{task.title}</h3>
          <p className="text-gray-700 text-base line-clamp-3 mb-6 leading-relaxed font-medium">{task.description}</p>
        </div>
        <div className="flex gap-3 ml-4">
          <button
            onClick={() => onEdit(task)}
            className="p-3 text-gray-500 hover:text-lavender-700 hover:bg-lavender-100 rounded-2xl transition-all duration-300 hover:scale-110 border border-gray-200 hover:border-lavender-300"
          >
            <Edit3 size={20} />
          </button>
          <button
            onClick={() => onDelete(task.id)}
            className="p-3 text-gray-500 hover:text-red-700 hover:bg-red-100 rounded-2xl transition-all duration-300 hover:scale-110 border border-gray-200 hover:border-red-300"
          >
            <Trash2 size={20} />
          </button>
        </div>
      </div>

      {/* Priority Badge */}
      <div className={`inline-flex items-center gap-3 px-5 py-3 rounded-2xl text-sm font-bold border-2 mb-6 shadow-lg ${styles.badge}`}>
        <Star size={16} fill="currentColor" />
        {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)} Priority
      </div>

      {/* Due Date */}
      <div className={`flex items-center gap-4 mb-6 text-sm p-4 rounded-2xl font-medium ${isOverdue ? 'text-red-800 bg-gradient-to-r from-red-50 to-red-100 border-2 border-red-200' : 'text-gray-800 bg-gradient-to-r from-gray-50 to-gray-100 border-2 border-gray-200'}`}>
        {isOverdue ? <AlertTriangle size={20} /> : <Calendar size={20} />}
        <span className="font-semibold">{formatDate(task.dueDate)}</span>
        {isOverdue && <span className="text-red-700 font-bold text-xs bg-red-200 px-3 py-1 rounded-full border border-red-300">OVERDUE</span>}
      </div>

      {/* Status Selector */}
      <div className="flex items-center justify-between bg-gradient-to-r from-gray-50 to-gray-100 p-5 rounded-2xl border-2 border-gray-200">
        <div className="flex items-center gap-4">
          <div className={`w-5 h-5 rounded-full shadow-lg border-2 border-white ${getStatusStyles(task.status)}`}></div>
          <span className="text-sm font-bold text-gray-800 capitalize font-display">
            {task.status.replace('-', ' ')}
          </span>
        </div>
        
        <select
          value={task.status}
          onChange={(e) => onUpdateStatus(e.target.value as Task['status'])}
          className="text-sm bg-white border-2 border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-4 focus:ring-lavender-500/30 focus:border-lavender-400 transition-all duration-300 font-semibold text-gray-800 shadow-sm"
        >
          <option value="pending">🕐 Pending</option>
          <option value="in-progress">⚡ In Progress</option>
          <option value="completed">✅ Completed</option>
        </select>
      </div>
    </div>
  );
};

export default TaskCard;
