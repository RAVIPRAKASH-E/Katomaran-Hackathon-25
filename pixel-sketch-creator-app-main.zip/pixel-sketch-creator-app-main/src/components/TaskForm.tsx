
import React, { useState, useEffect } from 'react';
import { X, Save, Calendar, FileText, Flag, Clock, Sparkles } from 'lucide-react';
import { Task } from '../types/Task';

interface TaskFormProps {
  task?: Task | null;
  onSubmit: (taskData: Omit<Task, 'id' | 'createdAt'>) => void;
  onClose: () => void;
}

const TaskForm: React.FC<TaskFormProps> = ({ task, onSubmit, onClose }) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    dueDate: '',
    status: 'pending' as Task['status'],
    priority: 'medium' as Task['priority']
  });

  useEffect(() => {
    if (task) {
      setFormData({
        title: task.title,
        description: task.description,
        dueDate: task.dueDate,
        status: task.status,
        priority: task.priority
      });
    }
  }, [task]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) return;
    
    onSubmit(formData);
    setFormData({
      title: '',
      description: '',
      dueDate: '',
      status: 'pending',
      priority: 'medium'
    });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-lg flex items-center justify-center p-6 z-50">
      <div className="bg-white/95 backdrop-blur-xl rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl border border-white/30">
        {/* Header */}
        <div className="sticky top-0 bg-gradient-to-r from-ocean-600 to-lavender-600 px-8 py-6 rounded-t-3xl border-b border-white/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-lg border border-white/30">
                <Sparkles className="w-7 h-7 text-white" />
              </div>
              <h2 className="text-2xl font-display font-bold text-white">
                {task ? 'Edit Task' : 'Create New Task'}
              </h2>
            </div>
            <button
              onClick={onClose}
              className="p-3 text-white hover:text-gray-200 hover:bg-white/20 rounded-2xl transition-all duration-300 border border-white/20 hover:border-white/40"
            >
              <X size={24} />
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-8">
          {/* Title Input */}
          <div>
            <label className="flex items-center gap-3 text-base font-bold text-gray-800 mb-4 font-display">
              <div className="p-2 bg-lavender-100 rounded-xl border border-lavender-200">
                <FileText size={18} className="text-lavender-700" />
              </div>
              Task Title
            </label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleChange}
              className="w-full px-6 py-4 border-2 border-gray-300 rounded-2xl focus:outline-none focus:ring-4 focus:ring-lavender-500/30 focus:border-lavender-400 transition-all duration-300 text-gray-900 font-semibold placeholder-gray-500 text-lg bg-white/80 backdrop-blur-sm"
              placeholder="What needs to be accomplished?"
              required
            />
          </div>

          {/* Description */}
          <div>
            <label className="flex items-center gap-3 text-base font-bold text-gray-800 mb-4 font-display">
              <div className="p-2 bg-ocean-100 rounded-xl border border-ocean-200">
                <FileText size={18} className="text-ocean-700" />
              </div>
              Description
            </label>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleChange}
              rows={4}
              className="w-full px-6 py-4 border-2 border-gray-300 rounded-2xl focus:outline-none focus:ring-4 focus:ring-ocean-500/30 focus:border-ocean-400 transition-all duration-300 resize-none text-gray-900 placeholder-gray-500 text-base font-medium bg-white/80 backdrop-blur-sm"
              placeholder="Describe the task in detail..."
            />
          </div>

          {/* Due Date */}
          <div>
            <label className="flex items-center gap-3 text-base font-bold text-gray-800 mb-4 font-display">
              <div className="p-2 bg-forest-100 rounded-xl border border-forest-200">
                <Calendar size={18} className="text-forest-700" />
              </div>
              Due Date
            </label>
            <input
              type="date"
              name="dueDate"
              value={formData.dueDate}
              onChange={handleChange}
              className="w-full px-6 py-4 border-2 border-gray-300 rounded-2xl focus:outline-none focus:ring-4 focus:ring-forest-500/30 focus:border-forest-400 transition-all duration-300 text-gray-900 font-semibold text-lg bg-white/80 backdrop-blur-sm"
              required
            />
          </div>

          {/* Priority */}
          <div>
            <label className="flex items-center gap-3 text-base font-bold text-gray-800 mb-4 font-display">
              <div className="p-2 bg-sunset-100 rounded-xl border border-sunset-200">
                <Flag size={18} className="text-sunset-700" />
              </div>
              Priority Level
            </label>
            <select
              name="priority"
              value={formData.priority}
              onChange={handleChange}
              className="w-full px-6 py-4 border-2 border-gray-300 rounded-2xl focus:outline-none focus:ring-4 focus:ring-sunset-500/30 focus:border-sunset-400 transition-all duration-300 text-gray-900 font-semibold text-lg bg-white/80 backdrop-blur-sm"
            >
              <option value="low">🟢 Low Priority</option>
              <option value="medium">🟡 Medium Priority</option>
              <option value="high">🔴 High Priority</option>
            </select>
          </div>

          {/* Status (only for editing) */}
          {task && (
            <div>
              <label className="flex items-center gap-3 text-base font-bold text-gray-800 mb-4 font-display">
                <div className="p-2 bg-gray-100 rounded-xl border border-gray-200">
                  <Clock size={18} className="text-gray-700" />
                </div>
                Status
              </label>
              <select
                name="status"
                value={formData.status}
                onChange={handleChange}
                className="w-full px-6 py-4 border-2 border-gray-300 rounded-2xl focus:outline-none focus:ring-4 focus:ring-gray-500/30 focus:border-gray-400 transition-all duration-300 text-gray-900 font-semibold text-lg bg-white/80 backdrop-blur-sm"
              >
                <option value="pending">🕐 Pending</option>
                <option value="in-progress">⚡ In Progress</option>
                <option value="completed">✅ Completed</option>
              </select>
            </div>
          )}

          {/* Submit Buttons */}
          <div className="flex gap-4 pt-8">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-8 py-4 border-2 border-gray-400 text-gray-700 rounded-2xl hover:bg-gray-100 hover:border-gray-500 transition-all duration-300 font-bold text-lg font-display"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 bg-gradient-to-r from-lavender-600 to-ocean-600 text-white px-8 py-4 rounded-2xl hover:from-lavender-700 hover:to-ocean-700 transition-all duration-300 transform hover:scale-[1.02] shadow-2xl hover:shadow-lavender-500/30 font-bold text-lg flex items-center justify-center gap-3 font-display border border-white/20"
            >
              <Save size={22} />
              {task ? 'Update Task' : 'Create Task'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default TaskForm;
