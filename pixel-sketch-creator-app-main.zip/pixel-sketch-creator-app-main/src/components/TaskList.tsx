
import React from 'react';
import TaskCard from './TaskCard';
import { Task } from '../types/Task';
import { Clock, Zap, CheckCircle2, Palette } from 'lucide-react';

interface TaskListProps {
  tasks: Task[];
  onEditTask: (task: Task) => void;
  onDeleteTask: (id: string) => void;
  onUpdateTask: (id: string, taskData: Omit<Task, 'id' | 'createdAt'>) => void;
}

const TaskList: React.FC<TaskListProps> = ({ 
  tasks, 
  onEditTask, 
  onDeleteTask, 
  onUpdateTask 
}) => {
  if (tasks.length === 0) {
    return (
      <div className="text-center py-24">
        <div className="w-36 h-36 mx-auto mb-8 bg-gradient-to-br from-lavender-200 to-ocean-300 rounded-full flex items-center justify-center shadow-2xl border border-white/30 backdrop-blur-sm">
          <Palette className="w-18 h-18 text-lavender-700" />
        </div>
        <h3 className="text-3xl font-display font-bold text-gray-800 mb-4">Your Workspace Awaits</h3>
        <p className="text-gray-600 text-xl font-medium">Create your first task to get started on your journey!</p>
      </div>
    );
  }

  const pendingTasks = tasks.filter(task => task.status === 'pending');
  const inProgressTasks = tasks.filter(task => task.status === 'in-progress');
  const completedTasks = tasks.filter(task => task.status === 'completed');

  const SectionHeader = ({ icon: Icon, title, count, gradient }: { 
    icon: any, 
    title: string, 
    count: number, 
    gradient: string 
  }) => (
    <div className={`${gradient} rounded-3xl p-6 mb-8 shadow-xl border border-white/20 backdrop-blur-sm`}>
      <h2 className="text-2xl font-display font-bold text-white mb-2 flex items-center gap-4">
        <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-lg border border-white/30">
          <Icon size={24} />
        </div>
        {title} ({count})
      </h2>
    </div>
  );

  return (
    <div className="space-y-12">
      {/* Pending Tasks */}
      {pendingTasks.length > 0 && (
        <div>
          <SectionHeader
            icon={Clock}
            title="Pending Tasks"
            count={pendingTasks.length}
            gradient="bg-gradient-to-r from-sunset-500 to-sunset-600"
          />
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {pendingTasks.map(task => (
              <TaskCard
                key={task.id}
                task={task}
                onEdit={onEditTask}
                onDelete={onDeleteTask}
                onUpdateStatus={(status) => onUpdateTask(task.id, { ...task, status })}
              />
            ))}
          </div>
        </div>
      )}

      {/* In Progress Tasks */}
      {inProgressTasks.length > 0 && (
        <div>
          <SectionHeader
            icon={Zap}
            title="In Progress"
            count={inProgressTasks.length}
            gradient="bg-gradient-to-r from-ocean-500 to-ocean-600"
          />
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {inProgressTasks.map(task => (
              <TaskCard
                key={task.id}
                task={task}
                onEdit={onEditTask}
                onDelete={onDeleteTask}
                onUpdateStatus={(status) => onUpdateTask(task.id, { ...task, status })}
              />
            ))}
          </div>
        </div>
      )}

      {/* Completed Tasks */}
      {completedTasks.length > 0 && (
        <div>
          <SectionHeader
            icon={CheckCircle2}
            title="Completed"
            count={completedTasks.length}
            gradient="bg-gradient-to-r from-forest-500 to-forest-600"
          />
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {completedTasks.map(task => (
              <TaskCard
                key={task.id}
                task={task}
                onEdit={onEditTask}
                onDelete={onDeleteTask}
                onUpdateStatus={(status) => onUpdateTask(task.id, { ...task, status })}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default TaskList;
